/**
 * Calculates premium and composite scores for corridors
 */

/**
 * Calculates USDT premium as (binancePrice / officialRate) - 1
 * @param {number} binancePrice
 * @param {number} officialRate
 * @returns {number|null}
 */
function calculatePremium(binancePrice, officialRate) {
  if (binancePrice === null || binancePrice === undefined ||
      officialRate === null || officialRate === undefined) {
    return null;
  }
  return (binancePrice / officialRate) - 1;
}

/**
 * Enriches corridors with premium, raw margin, and scoring
 * @param {Array} corridors - Array of corridor objects with flowUSD
 * @param {Object} binancePrices - currencyCode -> price map
 * @param {Object} officialRates - currencyCode -> rate map
 * @param {Object} currencyMap - destinationName -> currencyCode map
 * @param {Object} countryToIso3 - destinationName -> ISO-3 map
 * @returns {Array} Enriched corridors with premium, rawMargin, p2pStatus
 */
function enrichCorridors(corridors, binancePrices, officialRates, currencyMap, countryToIso3) {
  const enriched = corridors.map(corridor => {
    const { destinationName, flowUSD } = corridor;

    const currencyCode = currencyMap[destinationName];
    const iso3 = countryToIso3[destinationName];

    let premium = null;
    let p2pStatus = 'OK';

    if (!currencyCode) {
      p2pStatus = 'No currency mapping';
    } else {
      const binancePrice = binancePrices[currencyCode];
      const officialRate = officialRates[currencyCode];

      if (binancePrice === null || officialRate === null) {
        p2pStatus = 'No P2P data';
      } else {
        premium = calculatePremium(binancePrice, officialRate);
      }
    }

    const rawMargin = premium !== null ? flowUSD * premium : null;

    return {
      ...corridor,
      iso3,
      currencyCode,
      binancePrice: binancePrices[currencyCode] || null,
      officialRate: officialRates[currencyCode] || null,
      premium,
      rawMargin,
      p2pStatus,
      score: null, // Will be set after ranking
    };
  });

  return enriched;
}

/**
 * Ranks and scores corridors by raw margin
 * Score is a percentile: top = 100, bottom = 1
 */
function rankAndScore(corridors) {
  // Filter corridors with valid raw margins for ranking
  const validCorridors = corridors.filter(c => c.rawMargin !== null);

  // Sort by raw margin descending
  const sorted = [...validCorridors].sort((a, b) => b.rawMargin - a.rawMargin);

  // Calculate percentile score
  const n = validCorridors.length;
  const scoredCorridors = corridors.map(corridor => {
    if (corridor.rawMargin === null) {
      return { ...corridor, score: null };
    }

    const rank = sorted.findIndex(c => c === corridor) + 1; // 1-indexed
    const percentile = n === 1 ? 100 : Math.round(((n - rank) / (n - 1)) * 99) + 1;

    return {
      ...corridor,
      score: Math.max(1, Math.min(100, percentile)),
    };
  });

  return scoredCorridors;
}

/**
 * Processes corridors for a given market filter (UAE, Bahrain, or All)
 */
function processMarket(corridors, filterSender = null, currencyMap, countryToIso3, binancePrices, officialRates) {
  let filtered = corridors;

  if (filterSender) {
    filtered = corridors.filter(c => c.sender === filterSender);
  } else {
    // For 'All', aggregate by destination
    const aggregated = {};
    corridors.forEach(corridor => {
      const key = corridor.destinationName;
      if (!aggregated[key]) {
        aggregated[key] = {
          sender: 'All',
          destinationName: corridor.destinationName,
          flowUSD: 0,
        };
      }
      aggregated[key].flowUSD += corridor.flowUSD;
    });
    filtered = Object.values(aggregated);
  }

  // Enrich with P2P data
  const enriched = enrichCorridors(filtered, binancePrices, officialRates, currencyMap, countryToIso3);

  // Rank and score
  const scored = rankAndScore(enriched);

  // Sort by score descending for output
  return scored.sort((a, b) => {
    if (a.score === null && b.score === null) return 0;
    if (a.score === null) return 1; // No P2P data goes to bottom
    if (b.score === null) return -1;
    return b.score - a.score;
  });
}

module.exports = {
  calculatePremium,
  enrichCorridors,
  rankAndScore,
  processMarket,
};
